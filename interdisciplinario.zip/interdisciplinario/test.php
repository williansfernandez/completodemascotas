<?php
echo "¡PHP funciona!";
?>